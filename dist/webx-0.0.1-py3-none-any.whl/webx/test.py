import sys
import time
import argparse
import readConfig
import statusCheck
import multiprocessing
from datetime import datetime
from logs import mainLogger, getFileLogger
from concurrent.futures import ThreadPoolExecutor
from threading import Thread
import threading
import schedule

_lock = threading.Lock()

def job(n):
    print(n, datetime.now(), "I'm running on thread %s" % threading.current_thread())

def f(number,st):
    schedule.every(st).seconds.do(job, number)
    while True:
        _lock.acquire()
        schedule.run_pending()
        _lock.release()

def logResult(configItem, _key):
    fileLogger = getFileLogger('./{}.txt'.format('test'))
    while True:
        _lock.acquire()
        _result = statusCheck.check(configItem)
        _result['url'] = configItem.get('url')
        _result['checkTime'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        fileLogger.info(msg=_result)
        mainLogger.info(_key)
        mainLogger.info(configItem.get('checking_frequency').get('period'))
        # todo: convert period to seconds if unit is not sec
        time.sleep(configItem.get('checking_frequency').get('period'))
        _lock.release()



def logResult2(configItem, _key):
    while True:
        print(_key)
        print(configItem.get('checking_frequency').get('period'))
        time.sleep(100)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--logPath', required=False, type=str, default='.')
    parser.add_argument('--ConfigFilePath', required=True, type=str)
    args = parser.parse_args()
    logPath = args.logPath
    ConfigFilePath = args.ConfigFilePath
    ConfigFile = readConfig.readConfig(ConfigFilePath)
    if not ConfigFile:
        mainLogger.error('ConfigFile is missing or in wrong format')
        sys.exit()
    # todo: map items to threads
    #threads = []
    #threads = [Thread(target=logResult, args=(ConfigFile[_key],_key))
    #        for _key in ConfigFile.keys()]
    #for thread in threads:
    #    thread.start()
    #for thread in threads:
    #    thread.join()
    #for _key in ConfigFile.keys():
    #    t = Thread(target=logResult, args=(ConfigFile[_key],_key))
    #    threads.append(t)
    #    t.start()
    
    thread = threading.Thread(target=f, args=(1,10))
    thread2 = threading.Thread(target=f, args=(2,20))
    thread.start()
    thread2.start()
   # with ThreadPoolExecutor(18) as executor:
   #     l = list(executor.map(lambda _key: logResult(ConfigFile[_key], _key), ConfigFile.keys()))
            #print(_keyi)

